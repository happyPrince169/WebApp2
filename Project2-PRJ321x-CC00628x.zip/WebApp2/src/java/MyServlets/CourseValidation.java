/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MyServlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Lenovo
 */
@WebServlet(name = "CourseValidation", urlPatterns = {"/CourseValidation"})
public class CourseValidation extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Course Validation</title>");
            request.getRequestDispatcher("parts/meta.jsp").include(request, response);
            out.println("</head>");
            out.println("<body>");
            request.getRequestDispatcher("parts/header.jsp").include(request, response);
            out.println("<div class=\"container\">");
            out.println("<div class=\"row\">");
            request.getRequestDispatcher("parts/list.jsp").include(request, response);
            out.println("<div class=\"col-lg-9\">");
            out.println("<div class=\"card mt-4\">");
            String action = request.getParameter("action");
            if ("Submit".equals(action)) {

                String name = request.getParameter("name");
                String age = request.getParameter("age");
                int a = 0;
                String nation = request.getParameter("nations");
                String[] courses = request.getParameterValues("courses");
                String language = request.getParameter("languages");
                boolean validName;
                boolean validAge = true;
                boolean validNation = true;
                boolean validCourse = true;
                boolean validLang = true;
                Pattern p = Pattern.compile("([0-9])");
                Matcher m = p.matcher(name);
                //validate name
                if (name == null || name.trim().isEmpty() || m.find()) {
                    request.setAttribute("validname", "null");
                    validName = false;
                } else {
                    validName = true;
                }
                //kiem tra age
                if ((age == null) || (age.equals(""))) {
                    request.setAttribute("validAge", "null");
                    validAge = false;
                } else {
                    try {
                        a = Integer.parseInt(age);
                    } catch (NumberFormatException e) {
                        request.setAttribute("validAge", "null");
                        validAge = false;
                    }
                    if (a > 40 || a < 18) {
                        request.setAttribute("validAge", "null");
                        validAge = false;
                    }
                }
                //kiem tra quoc gia
                if (nation.equals("0")) {
                    request.setAttribute("validNation", "null");
                    validNation = false;
                } else {
                    validNation = true;
                }
                //kiem tra course
                //out.println("<p>" + courses.length + "</p>");
                if (courses == null) {
                    request.setAttribute("validCourse", "null");
                    validCourse = false;
                } else {
                    validCourse = true;
                }
                //kiem tra radio box language

                if (language == null) {
                    request.setAttribute("validLang", "null");
                    validLang = false;
                }
                //chuyen ve form neu thong tin chua hop le
                if (!validName || !validAge || !validNation || !validCourse || !validLang) {
                    RequestDispatcher requestDispatcher = request.getRequestDispatcher("pages/page1.jsp");
                    requestDispatcher.forward(request, response);
                } else {
                    out.println("<h1>Student Information</h1>");
                    out.println("<h4><b>Họ và tên:</b> " + name + "</h4>");
                    out.println("<h4><b>Tuổi:</b> " + age + "</h4>");
                    out.println("<h4><b>Quốc tịch:</b> " + nation + "</h4>");
                    out.print("<h4><b>Khóa học:</b> ");
                    for (String course : courses) {
                        out.print(course+", ");
                    }
                    out.print("</h4>");
                    out.println("<h4><b>Ngôn ngữ:</b> " + language + "</h4>");

                }
            } else if ("Cancel".equals(action)) {
                response.sendRedirect("pages/welcome.jsp");
            }
            out.println("</div>");
            out.println("</div>");
            out.println("</div>");
            out.println("</div>");
            request.getRequestDispatcher("parts/footer.jsp").include(request, response);
            out.println("<script src=\"/WebApp2/vendor/jquery/jquery.min.js\"></script>");
            out.println("<script src=\"/WebApp2/vendor/bootstrap/js/bootstrap.bundle.min.js\"></script>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    private boolean validateName(String name, HttpServletRequest request) {
        if (name == null || name.trim().isEmpty()) {
            request.setAttribute("validname", "null");
            return false;
        } else {
            return true;
        }
    }

    private boolean validateAge(String a, HttpServletRequest request) {
        int age = Integer.parseInt(a);
        if (age < 18 || age > 40 || a == null || a.trim().isEmpty()) {
            request.setAttribute("validAge", "null");
            return false;
        } else {
            return true;
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
